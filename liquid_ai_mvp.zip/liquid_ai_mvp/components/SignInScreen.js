/*
 * SignInScreen
 *
 * A simple sign‑in screen for the LiquidAI MVP application. This screen
 * presents a form for the user to enter a username. If the username
 * field is empty, an error message is displayed. Otherwise, the
 * `onSignIn` callback is invoked with the provided username.
 *
 * This file uses React Native's built‑in components along with
 * TailwindCSS for styling. Feel free to customize styles or add
 * additional form fields (e.g. password) to suit your needs.
 */

import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';

export default function SignInScreen({ onSignIn }) {
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');

  /**
   * Handle sign‑in button press. Validate the username and trigger
   * the provided callback if valid.
   */
  const handleSignIn = () => {
    if (!username.trim()) {
      setError('Please enter a username');
      return;
    }
    setError('');
    onSignIn(username.trim());
  };

  return (
    <View className="flex-1 items-center justify-center p-4 bg-white">
      <Text className="text-2xl font-bold mb-4">Welcome to LiquidAI</Text>
      <TextInput
        className="w-full border border-gray-300 rounded-lg px-4 py-2 mb-2"
        placeholder="Enter your username"
        value={username}
        onChangeText={setUsername}
        autoCapitalize="none"
      />
      {error ? (
        <Text className="text-red-500 mb-2">{error}</Text>
      ) : null}
      <TouchableOpacity
        className="w-full bg-blue-500 py-3 rounded-lg items-center"
        onPress={handleSignIn}
      >
        <Text className="text-white font-semibold">Sign In</Text>
      </TouchableOpacity>
    </View>
  );
}