/*
 * ChatScreen
 *
 * A basic chat interface for the LiquidAI MVP application. The chat
 * screen displays a list of messages and provides a text input for
 * sending new messages. Messages from the user are aligned to the
 * right, while messages from the "bot" are aligned to the left.
 *
 * The `messages` prop is expected to be an array of objects with
 * `id`, `sender`, and `text` properties. The `onSend` callback
 * should accept a string representing the user's message and append
 * it to the conversation.
 */

import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList } from 'react-native';

export default function ChatScreen({ messages, onSend }) {
  const [input, setInput] = useState('');

  /**
   * Handle sending a new message. Reset the input field and call
   * the provided `onSend` callback.
   */
  const handleSend = () => {
    const trimmed = input.trim();
    if (!trimmed) return;
    onSend(trimmed);
    setInput('');
  };

  /**
   * Render each message in the FlatList. Messages from the user are
   * displayed on the right with a distinct background color, while
   * bot messages are on the left.
   */
  const renderMessageItem = ({ item }) => {
    const isUser = item.sender === 'user';
    return (
      <View
        className={`flex-row ${isUser ? 'justify-end' : 'justify-start'} mb-2`}
        key={item.id}
      >
        <View
          className={`max-w-xs rounded-lg p-3 ${
            isUser ? 'bg-blue-500' : 'bg-gray-200'
          }`}
        >
          <Text className={isUser ? 'text-white' : 'text-gray-800'}>
            {item.text}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <View className="flex-1 bg-white">
      {/* Message list */}
      <FlatList
        data={messages}
        renderItem={renderMessageItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={{ padding: 16 }}
      />
      {/* Input bar */}
      <View className="flex-row items-center p-4 border-t border-gray-200">
        <TextInput
          className="flex-1 border border-gray-300 rounded-lg px-4 py-2 mr-2"
          placeholder="Type your message..."
          value={input}
          onChangeText={setInput}
          multiline
        />
        <TouchableOpacity
          className="bg-blue-500 p-3 rounded-lg"
          onPress={handleSend}
        >
          <Text className="text-white font-semibold">Send</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}