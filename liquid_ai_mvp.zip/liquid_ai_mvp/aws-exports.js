// Placeholder AWS Amplify configuration
// Replace the values below with your AWS Amplify project configuration.
const awsmobile = {
  aws_project_region: 'YOUR_AWS_REGION',
  aws_cognito_region: 'YOUR_AWS_REGION',
  aws_user_pools_id: 'YOUR_USER_POOL_ID',
  aws_user_pools_web_client_id: 'YOUR_USER_POOL_CLIENT_ID',
  oauth: {},
  aws_appsync_graphqlEndpoint: 'YOUR_GRAPHQL_ENDPOINT',
  aws_appsync_region: 'YOUR_AWS_REGION',
  aws_appsync_authenticationType: 'AMAZON_COGNITO_USER_POOLS'
};

export default awsmobile;